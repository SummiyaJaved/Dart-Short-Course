void main()
{
  var person={
    'name': 'Andrea',
    'age' : 23,
    'height' : 22
  };

  person['weight']=23;
print(person['weight']);
}