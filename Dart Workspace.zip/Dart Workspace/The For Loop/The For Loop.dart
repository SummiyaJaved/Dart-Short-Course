void main()
{
final value=[1,2,3,4];
print(sum(value));

}
int sum(List<int> value)
{
  //int i=0;
  int result=0;
  // for(int i=0; i< value.length; i++)
  //   {
  //     result += value[i];
  //     i++;
  for(int values in value)
  {
    result += values;
  }
  return result;
    }





