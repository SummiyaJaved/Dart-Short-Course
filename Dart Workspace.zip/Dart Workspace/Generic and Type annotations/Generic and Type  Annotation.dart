void main()
{
  var primeNumbers=List<int>();
  primeNumbers.addAll([5,6,7,13]);

  var person={
    'name':'Andrea',
    'age': 23,
    'height': 3.3

  };

  person['weight'] = 22;
  print(person['weight']);
  print(primeNumbers);
}

List getFourPrimeNumbers() => [5,6,7,13];