
  void main()
  {
    printError(NetworkError.bad_URL);
    //printError(NetworkError.timeout);
    //printError(NetworkError.resourceNotAvailable);


  }
  enum NetworkError{
bad_URL,
timeout,
resourceNotAvailable,
}

  void printError(NetworkError error) {
    switch(error) {
      case NetworkError.bad_URL:
      print('bad url');
      break;
    }

    switch(error) {
      case NetworkError.bad_URL:
      print('time out');
      break;
    }

    switch(error) {
      case NetworkError.bad_URL:
      print('resources not available');
      break;
    }
  }