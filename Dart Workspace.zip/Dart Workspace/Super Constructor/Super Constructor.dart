void main()
{

    //final person=Person();
    //print(person.describe());
    final employee= Employee(name: 'Sam', age: 22 , height: 3.4 ,taxcode: 'asb23', salary: 2000);
    employee.myname();
}

class Person{
  Person({this.name, this.age,this.height});
  final String name;
  final int age;
  final double height;


String describe() => "my name is $name, my age is $age, my height is $height";

void myname() => print("Hello,my name is $name");


}

class Employee extends Person{

  Employee({String name, int age, double height,this.taxcode, this.salary}):
  super(name: name, age: age, height: height);
  final String taxcode;
  final int salary;
}