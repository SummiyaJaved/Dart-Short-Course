void main()
{
printError(NetworkError.bad_URL);

}
enum NetworkError{
  bad_URL,
  timeout,
  resourceNotAvailable
}

void printError(NetworkError error)
{
  if(error==NetworkError.bad_URL)
    {
      print('bad url');

    }
  else if (error==NetworkError.timeout)
    {
      print('Timeout Error');
    }
  else if(error==NetworkError.resourceNotAvailable)
    {
      print('resources are not available');
    }
}