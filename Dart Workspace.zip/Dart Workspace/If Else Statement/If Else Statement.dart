void main()
{
  EvenOddNumbers(8);
}

void EvenOddNumbers(int value)
{
  if(value%2==0)
    {
      print('$value is even');
    }
  else
    print('$value is odd');
}
