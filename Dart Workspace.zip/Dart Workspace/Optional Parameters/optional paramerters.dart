void main()
{
  var name='ali';
  var age=22;
  var height=3.4;

  final person1 = describe (name,age);
  final person2= describe('ali',22,3.4);
  print(person1);
  print(person2);

}
String describe(String name,int age,[double height])
{
return("my name is $name.My age is $age,my height is $height");
}
