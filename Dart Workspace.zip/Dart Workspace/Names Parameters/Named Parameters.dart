 void main()
 {

 String name="Sam";
 int age=22;
 double height=3.4;

 final person1=describe(name: name, age: age, height: height);
 final person2=describe(name: "sam", age: 22, height: 3.4);

 print(person1);
 print(person2);

}
String describe({String name,int age,double height=0.0})
{
  return("My name is $name,my age is $age, my height is $height");
}