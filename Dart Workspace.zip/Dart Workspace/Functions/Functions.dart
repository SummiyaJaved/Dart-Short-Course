void main()
{
  var name="honey";
 var age=22;
  var height=3.4;

describe(name, age, height);
describe('honey', 22,3.4);

}

void describe(String name,int age, double height)
{
  print("my name is $name");
  print("my age is $age");
  print("my height is $height");
  print ("my name has ${name.length} letters");

}