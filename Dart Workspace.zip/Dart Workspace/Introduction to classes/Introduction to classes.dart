void main()
{

 final person= Person( name:'',age:20,height:3.2);
 person.name='ali';
 print(person.name);
 print(person.age);
  // var name='sam';
  // var age=20;
  // var height=3.4;
  //
  // final person1=describe(name: name, age: age, height: height);
  // final person2=describe(name: 'ali', age:20, height: 3.1);
  // print(person1);
  // print(person2);

}
class Person
{
  Person({this.name,this.age, this.height});
 var name;
 var age;
 var height;

}

String describe({var name, var age, var height=0.0})
{
  return("my name is $name, my age is $age, my height is $height");
}

String describe2(var name, var age, var height) =>
    (",y name is $name, my age is $age, my height is $height");

void sayname(var name) =>
    print("Hello, my name is $name");