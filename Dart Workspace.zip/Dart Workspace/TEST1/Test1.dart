void main()
{
  print('summiya');
}