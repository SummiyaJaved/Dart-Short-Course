void main() {
  String name = "usman";
  int age = 18;
  double height = 3.4;

  final person1 = describe(name: name, age: age, height: height);
  final person2 = describe(name: "ali", age: 22, height: 3.4);
  print(person1);
  print(person2);
}

String describe({String name, int age, double height = 0.0}) {
  return ("my name is $name, my age is $age, my height is $height");
}

// String describe2({String name, int age, double height = 0.0}) =>
//     ("my name is $name, my age is $age, my height is $height");
//
// //void sayName(String name) => print("This is my $name");