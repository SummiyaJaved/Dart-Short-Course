void main()
{
final person= Person(name:'andrea',age:34, height:4.5);
print(person.describe());
}

class Person
{
  Person({this.name, this.age,this.height});

  final String name;
  final int age;
  final double height;

  String describe() =>
  "my name is $name,my age is $age,my height is $height";

void sayName() => print("my name is $name");

}