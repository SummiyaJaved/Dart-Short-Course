void main() {
  var primeNumbers = [1, 3, 5, 7];
  primeNumbers.addAll([11,13,17,19]);
  primeNumbers.addAll([23]);

  print(primeNumbers);
}