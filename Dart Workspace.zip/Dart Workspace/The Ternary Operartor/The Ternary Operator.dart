void main()
{
  EvenOddNumbers(3);
  EvenOddNumbers(4);
}

void EvenOddNumbers(int value)
{
  final type=(value%2==0) ? 'even' : 'odd';
  print('$value is $type');

}
