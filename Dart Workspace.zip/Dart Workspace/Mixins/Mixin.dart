 mixin BMI() {
   double calculateBMI(double:weight, double:height)
   {
     return weight / (height * weight);
   }
 }
class Person with BMI {

  Person({this.name, this.age, this.height, this.weight});

  final String name;
  final int age;
  final double height;
  final double weight;

  double get mixi =>calculateBMI(weight,height);
}
void main()
{
  final person=Person(name:'Andrea',age:40,height:4,weight:2);
  print(person.bmi());
}

}