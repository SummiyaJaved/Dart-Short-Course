void main() {

  // we can write like this in " VAR " and also we can write as the code is written after comments.
  //


  // String name = "Summiya Javed";
  // int age = 22;
  // double height = 3.4;
  // // print("my name is $name");
  // // print("my name has ${name.length} letters");
  // // print("my age is $age");
  // // print("my height is $height");

   var name = "Summiya Javed";
var age = 22;
 var height = 3.4;
  print("my name is $name");
   print("my name has ${name.length} letters");
   print("my age is $age");
   print("my height is $height");
}
