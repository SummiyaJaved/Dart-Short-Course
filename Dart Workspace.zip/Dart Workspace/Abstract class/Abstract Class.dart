void main()
{
final square= Square(side: 10);
print(square.area());

}

abstract class Shape{
 void area();
}

class Square implements Shape{
 Square({this.side});
 final double side;
 double area() =>(side*side);

}