void main()
{
 final employee= Employee(name: 'Mehrab_Ali', age: 25 , height: 3.4, taxcode:'Ab34', salary: 349900);
 employee.sayName();
 print(employee);

}
class Person
{
 Person({this.name, this .age, this.height});
final String name;
final int age;
final double height;

@override
 String toString() =>'name: $name , age: $age, salary:$age';

String describe() => "My name is $name, my age is $age, my salary is $height";

void sayName() =>" Hello, my name is $name";


}
 class Employee extends Person{

  Employee({String name, int age, double height,this.taxcode, this .salary})
      : super(name: name, age: age, height: height);

  final String taxcode;
  final int salary;

  @override
 String toString() => "${super.toString()},taxcode: $taxcode, salary: $salary";

 }