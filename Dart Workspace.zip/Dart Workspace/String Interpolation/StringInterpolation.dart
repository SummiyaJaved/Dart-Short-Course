void main()
{
  String name="Summiya javed";
 print("Hello, i'm ${name.length} letters");
}